﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WPFCrudApp.Data;

namespace WPFCrudApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            this.dbContext = new ProductDbContext();
            GetProducts();
            InitializeComponent();
            AddNewProductGrid.DataContext = NewProduct;
        }

        ProductDbContext dbContext;
        Product NewProduct = new Product();

     
        private void GetProducts()
        {
            ProductDG.ItemsSource = dbContext.Products.ToList();
        }

        private void AddProduct(object s, RoutedEventArgs e)
        {
            dbContext.Products.Add(NewProduct);
           
            GetProducts();
            NewProduct = new Product();
            AddNewProductGrid.DataContext = NewProduct;
        }

        Product selectedProduct = new Product();
        private void UpdateProductForEdit(object s, RoutedEventArgs e)
        {
            selectedProduct = (s as FrameworkElement).DataContext as Product;
            UpdateProductGrid.DataContext = selectedProduct;
        }

        private void UpdateProduct(object s, RoutedEventArgs e)
        {
            MessageBox.Show(this.selectedProduct.Description);
            var thisProduct = (from prod in this.dbContext.Products
                               where prod.Id == selectedProduct.Id
                               select prod).SingleOrDefault();
            thisProduct.Description = selectedProduct.Description;
            thisProduct.Name = selectedProduct.Name;
            thisProduct.Price = selectedProduct.Price;
            thisProduct.Unit = selectedProduct.Unit;
            GetProducts();
        }

        private void DeleteProduct(object s, RoutedEventArgs e)
        {
            var productToBeDeleted = (s as FrameworkElement).DataContext as Product;
            this.dbContext.Products.Remove(productToBeDeleted);
            GetProducts();
        }
    }
}
